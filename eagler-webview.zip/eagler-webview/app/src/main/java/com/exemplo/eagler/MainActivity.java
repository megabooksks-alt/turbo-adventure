package com.exemplo.eagler;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.webkit.*;

public class MainActivity extends Activity {
    // Endereço que o app abre (o mesmo do APK original)
    private static final String ENDERECO = "https://eaglercraft.com/";
    private WebView web;
    private ValueCallback<Uri[]> arquivo;

    @Override
    protected void onCreate(Bundle estado) {
        super.onCreate(estado);
        web = new WebView(this);
        web.setBackgroundColor(0xFF000000);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public void onReceivedError(WebView v, WebResourceRequest r, WebResourceError e) {
                if (r.isForMainFrame()) semConexao();
            }
        });
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> retorno, FileChooserParams p) {
                if (arquivo != null) arquivo.onReceiveValue(null);
                arquivo = retorno;
                Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("*/*");
                startActivityForResult(i, 1);
                return true;
            }
        });
        web.loadUrl(ENDERECO);
    }

    @Override
    protected void onActivityResult(int pedido, int resultado, Intent dados) {
        if (pedido == 1 && arquivo != null) {
            arquivo.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultado, dados));
            arquivo = null;
        }
    }

    private void semConexao() {
        if (isFinishing()) return;
        new AlertDialog.Builder(this)
            .setMessage("Não foi possível abrir o site. Verifique a internet.")
            .setPositiveButton("Tentar de novo", (d, w) -> web.reload())
            .setNegativeButton("Sair", (d, w) -> finish())
            .show();
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }
}
